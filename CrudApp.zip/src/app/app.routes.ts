import { Routes } from '@angular/router';
import { ReadComponent } from './components/read/read.component';
import { AddComponent } from './components/add/add.component';
import { EditComponent } from './components/edit/edit.component';
import { HomeComponent } from './components/home/home.component';

export const routes: Routes = [

    {path:'home', component:HomeComponent},
    {path:'list', component:ReadComponent},
    {path:'add', component:AddComponent},
    {path:'edit/:id', component:EditComponent}
];

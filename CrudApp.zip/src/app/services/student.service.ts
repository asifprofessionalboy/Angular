import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Data } from '../models/data'; // Adjust the path as per your project structure

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http: HttpClient) { }

  //Get All Data
  getData(): Observable<Data[]> {
    return this.http.get<Data[]>("http://localhost:3000/student");
  }

  // Insert data

  createData(data:Data){
    return this.http.post<Data>("http://localhost:3000/student",data);
  }

  // Get Id

  getDataById(id:number){
    return this.http.get<Data>(`http://localhost:3000/student/${id}`)
  }

   // Update or Edit Data

   upDateData(data:Data){
    return this.http.put<Data>(`http://localhost:3000/student/${data.id}`,data)
   }

}
export interface Data {
    id:number,
    name:string,
    address:string
}


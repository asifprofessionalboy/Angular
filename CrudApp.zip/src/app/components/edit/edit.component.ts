import { Component } from '@angular/core';
import { ActivatedRoute, Data } from '@angular/router';
import { Router } from 'express';
import { StudentService } from '../../services/student.service';

@Component({
  selector: 'app-edit',
  standalone: true,
  imports: [],
  templateUrl: './edit.component.html',
  styleUrl: './edit.component.css'
})
export class EditComponent {
MyData:Data ={
  id:0,
  name:'',
  address:''
}

constructor(private activateRoute:ActivatedRoute, private router: Router,
  private ds:StudentService){}

ngOnInit():void {

  this.activateRoute.paramMap.subscribe((p) =>{
    var id =Number(p.get('id'));
  })
  
}

getDataById(id:number){
this.ds.getDataById(id).subscribe((data) =>{
  this.MyData = data;
})
}

}

import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Data } from '../../models/data';

@Component({
  selector: 'app-read',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './read.component.html',
  styleUrl: './read.component.css',
  providers: [StudentService],
})


export class ReadComponent implements OnInit {
 
allData:Data[] =[];

  constructor(private ds: StudentService) {}


  ngOnInit()  {
    this.ds.getData().subscribe((res) => {
      this.allData = res;
      console.log(this.allData);
    });
  }
 
}

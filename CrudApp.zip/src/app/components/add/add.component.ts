import { Component } from '@angular/core';
import { Data } from '../../models/data';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { StudentService } from '../../services/student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent {
  dataFromHub: Data = {
    id: 0,
    name: '',
    address: ''
  };

  constructor(private ds: StudentService, private router: Router) {}

  ngOnInit(): void {}

  postData(): void {
    this.ds.createData(this.dataFromHub).subscribe({
      next: (res) => {
        this.router.navigate(['/list'])
      },
      error:(err) => {
        console.log(err);
      }
    });
  }
}

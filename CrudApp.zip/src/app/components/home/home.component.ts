import { Component } from '@angular/core';
import { AddComponent } from "../add/add.component";
import { ReadComponent } from "../read/read.component";

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [AddComponent, ReadComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

}

import { Component } from '@angular/core';

import { RouterOutlet } from '@angular/router';
import { UserComponent } from './user/user.component';
import { InterpolationComponent } from './interpolation/interpolation.component';
import { BindingComponent } from './binding/binding.component';
import { FormsModule } from '@angular/forms';
import { DirectivesComponent } from './directives/directives.component';
import { PipesComponent } from './pipes/pipes.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    UserComponent,
    InterpolationComponent,
    BindingComponent,
    DirectivesComponent,
    PipesComponent,
    FormsModule,
  ],


  
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  preserveWhitespaces:true
 
})

export class AppComponent {
  title = 'Asif Akhtar';
}

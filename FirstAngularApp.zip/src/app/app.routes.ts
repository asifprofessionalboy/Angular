import { Routes } from '@angular/router';
import { BindingComponent } from './binding/binding.component';
import { pipe } from 'rxjs';
import { PipesComponent } from './pipes/pipes.component';
import { UserComponent } from './user/user.component';

export const routes: Routes = [
    {path:'bind', component:BindingComponent},
    {path:'pipe', component:PipesComponent},
    {path:'user', component:UserComponent}
];

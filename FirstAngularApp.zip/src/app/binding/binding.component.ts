import { Component } from '@angular/core';

@Component({
  selector: 'app-binding',
  standalone: true,
  imports: [],
  templateUrl: './binding.component.html',
  styleUrl: './binding.component.css'
  
})
export class BindingComponent {

  public DisplayName="";

  // Get input text Value
   getName(value:string){

alert(value);
// console.log(value)
// this.DisplayName=value

  }

getHeading(value:string){
  this.DisplayName=value
}

// Counter Incremet Descrement
public val:number=0;

public Counter(str:string){
    (str ==='add') ? this.val++ : this.val--
}

// Two way Binding
public name="Asif"

}

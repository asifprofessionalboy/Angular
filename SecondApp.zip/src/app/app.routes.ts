import { Routes } from '@angular/router';
import { BindingComponent } from './binding/binding.component';
import { DirectivesComponent } from './directives/directives.component';
import { InterpolationComponent } from './interpolation/interpolation.component';
import { PipesComponent } from './pipes/pipes.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

export const routes: Routes = [
  //  {path:'', component:BindingComponent}, //must be first
  {path:'', redirectTo:'/bind', pathMatch:'full'}, //must be first
    {path:'bind', component:BindingComponent},
    {path:'directive', component:DirectivesComponent},
    {path:'interpolation', component:InterpolationComponent},
    {path:'pipe', component:PipesComponent},
    {path:'template' , component: TemplateDrivenFormComponent},
  {path:'**', component:PageNotFoundComponent}, //404 must be last
 
    
];

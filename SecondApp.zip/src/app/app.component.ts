import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { UserComponent } from './user/user.component';
import { InterpolationComponent } from './interpolation/interpolation.component';
import { BindingComponent } from './binding/binding.component';
import { FormsModule } from '@angular/forms';
import { DirectivesComponent } from './directives/directives.component';
import { PipesComponent } from './pipes/pipes.component';
import { TemplateDrivenFormComponent } from './template-driven-form/template-driven-form.component';
import { HttpClientModule } from '@angular/common/http';
import { GetDataService } from './services/get-data.service';
import { CommonModule, JsonPipe, SlicePipe } from '@angular/common';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    UserComponent,
    InterpolationComponent,
    BindingComponent,
    DirectivesComponent,
    PipesComponent,
    FormsModule,
    TemplateDrivenFormComponent,
    HttpClientModule,
    JsonPipe,
    SlicePipe,
  ],
  providers: [GetDataService],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  preserveWhitespaces: true,
})
export class AppComponent implements OnInit {
  title = 'Asif Akhtar';

  gets: any;

  constructor(private get: GetDataService) {}

  ngOnInit() {
    this.get.getdata().subscribe(response => {
      this.gets = response;
      console.log(this.gets);
    });
  }
}

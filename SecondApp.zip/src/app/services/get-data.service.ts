import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GetDataService {

private url='https://jsonplaceholder.typicode.com/posts';


  constructor(private client:HttpClient) { }

  getdata(){
    return this.client.get(this.url);
  }
}

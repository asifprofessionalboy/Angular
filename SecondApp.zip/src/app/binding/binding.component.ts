import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-binding',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './binding.component.html',
  styleUrl: './binding.component.css'
  
})
export class BindingComponent {

  public DisplayName="";

  // Get input text Value
   getName(value:string){

alert(value);
// console.log(value)
// this.DisplayName=value

  }

getHeading(value:string){
  this.DisplayName=value
}

// Counter Incremet Descrement
public val:number=0;

public Counter(str:string){
    (str ==='add') ? this.val++ : this.val--
}

// Two way Binding
public name="Asif"

names: string = '';

//propery binding

 imageUrl: string = 'https://example.com/image.jpg'
}

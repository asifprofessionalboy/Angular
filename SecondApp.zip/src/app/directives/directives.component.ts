import { Component } from '@angular/core';

@Component({
  selector: 'app-directives',
  standalone: true,
  imports: [],
  templateUrl: './directives.component.html',
  styleUrl: './directives.component.css'
})
export class DirectivesComponent {

//if directives
  isLoggedin:boolean=false
  isValid=true

  login(){
    this.isLoggedin=true
  }
  logout(){
    this.isLoggedin=false
  }

OnChange(val:any){
  this.isValid=val
}
//-----------------

//for directives

Employee:any[]=[

  {id:1,name:'Asif'},
  {id:2,name:'Irshad'},
  {id:3,name:'Sadaf'},
  {id:4,name:'Tasleem'}

]

}
